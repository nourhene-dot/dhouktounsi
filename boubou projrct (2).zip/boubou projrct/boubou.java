// Handle "Add to Cart" functionality
let cart = [];
const cartLink = document.getElementById("cart-link");
const cartCount = document.getElementById("cart-count");
const cartModal = document.getElementById("cart-modal");
const cartItemsList = document.getElementById("cart-items-list");
const cartTotal = document.getElementById("cart-total");

const addToCartButtons = document.querySelectorAll('.btn-add-to-cart');

addToCartButtons.forEach(button => {
    button.addEventListener('click', function() {
        const product = button.getAttribute('data-product');
        const price = parseFloat(button.getAttribute('data-price'));
        cart.push({ product, price });
        updateCart();
    });
});

function updateCart() {
    cartCount.textContent = cart.length;
    cartItemsList.innerHTML = '';
    let total = 0;
    
    cart.forEach(item => {
        const listItem = document.createElement('li');
        listItem.textContent = `${item.product} - $${item.price.toFixed(2)}`;
        cartItemsList.appendChild(listItem);
        total += item.price;
    });

    cartTotal.textContent = total.toFixed(2);
}

cartLink.addEventListener('click', function() {
    cartModal.style.display = 'flex';
});

document.getElementById("close-cart-btn").addEventListener('click', function() {
    cartModal.style.display = 'none';
});





// Assuming you're using a cart icon to toggle the modal
const cartButton = document.querySelector('.cart-btn');
const cartModal = document.querySelector('.cart-modal');
const closeCartButton = document.querySelector('.cart-modal-content button');

// Show the cart modal when the cart button is clicked
cartButton.addEventListener('click', function () {
    cartModal.style.display = 'flex';
});

// Hide the cart modal when the close button is clicked
closeCartButton.addEventListener('click', function () {
    cartModal.style.display = 'none';
});

// Hide the cart modal when clicked outside the modal content
window.addEventListener('click', function (e) {
    if (e.target === cartModal) {
        cartModal.style.display = 'none';
    }
});
